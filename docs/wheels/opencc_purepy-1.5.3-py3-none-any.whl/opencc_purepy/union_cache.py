from enum import Enum, auto
from typing import Dict, List

from .starter_union import DictSlot, StarterUnion


class UnionKey(Enum):
    S2T = auto()
    S2T_PUNCT = auto()
    T2S = auto()
    T2S_PUNCT = auto()
    TwVariantsPair = auto()
    TwTriple = auto()
    TwRevPair = auto()
    TwRevTriple = auto()
    HkTriple = auto()
    HkRevTriple = auto()
    HkVariantsPair = auto()
    HkRevPair = auto()
    JpsCharactersRev = auto()
    JpsPair = auto()
    SealCharactersOnly = auto()
    SealCharactersRevOnly = auto()
    SealVariantsOnly = auto()
    SealVariantsRevOnly = auto()
    StPunctOnly = auto()


class UnionCache:
    """On-demand cache for starter-union dictionary combinations."""

    def __init__(self, dictionary: object) -> None:
        self._dict = dictionary
        self._union_by_key: Dict[UnionKey, StarterUnion] = {}
        self._merged_slot_by_key: Dict[UnionKey, DictSlot] = {}

    def get_union(self, key: UnionKey, indexed: bool = False) -> StarterUnion:
        union = self._union_by_key.get(key)
        if union is None:
            union = self._build_union(key)
            self._union_by_key[key] = union
        if indexed and not union.indexed:
            union.build_starter_index()
        return union

    def get_merged_slot(self, key: UnionKey) -> DictSlot:
        slot = self._merged_slot_by_key.get(key)
        if slot is None:
            union = self.get_union(key)
            slot = (union.merged_map, union.cap)
            self._merged_slot_by_key[key] = slot
        return slot

    def ensure_indexed(self, key: UnionKey) -> StarterUnion:
        return self.get_union(key, indexed=True)

    def _build_union(self, key: UnionKey) -> StarterUnion:
        return StarterUnion.merge_precedence(self._slots_for(key))

    def _slots_for(self, key: UnionKey) -> List[DictSlot]:
        get_slot = self._get

        if key is UnionKey.S2T:
            return [get_slot("st_phrases"), get_slot("st_characters")]
        if key is UnionKey.S2T_PUNCT:
            return [get_slot("st_phrases"), get_slot("st_characters"), get_slot("st_punctuations")]
        if key is UnionKey.T2S:
            return [get_slot("ts_phrases"), get_slot("ts_characters")]
        if key is UnionKey.T2S_PUNCT:
            return [get_slot("ts_phrases"), get_slot("ts_characters"), get_slot("ts_punctuations")]
        if key is UnionKey.TwVariantsPair:
            return [get_slot("tw_variants_phrases"), get_slot("tw_variants")]
        if key is UnionKey.TwTriple:
            return [get_slot("tw_phrases"), get_slot("tw_variants_phrases"), get_slot("tw_variants")]
        if key is UnionKey.TwRevPair:
            return [get_slot("tw_variants_rev_phrases"), get_slot("tw_variants_rev")]
        if key is UnionKey.TwRevTriple:
            return [get_slot("tw_phrases_rev"), get_slot("tw_variants_rev_phrases"), get_slot("tw_variants_rev")]
        if key is UnionKey.HkTriple:
            return [get_slot("hk_phrases"), get_slot("hk_variants_phrases"), get_slot("hk_variants")]
        if key is UnionKey.HkRevTriple:
            return [get_slot("hk_phrases_rev"), get_slot("hk_variants_rev_phrases"), get_slot("hk_variants_rev")]
        if key is UnionKey.HkVariantsPair:
            return [get_slot("hk_variants_phrases"), get_slot("hk_variants")]
        if key is UnionKey.HkRevPair:
            return [get_slot("hk_variants_rev_phrases"), get_slot("hk_variants_rev")]
        if key is UnionKey.JpsCharactersRev:
            return [get_slot("jps_characters_rev")]
        if key is UnionKey.JpsPair:
            return [get_slot("jps_phrases"), get_slot("jps_characters")]
        if key is UnionKey.SealCharactersOnly:
            return [get_slot("seal_characters")]
        if key is UnionKey.SealCharactersRevOnly:
            return [get_slot("seal_characters_rev")]
        if key is UnionKey.SealVariantsOnly:
            return [get_slot("seal_variants")]
        if key is UnionKey.SealVariantsRevOnly:
            return [get_slot("seal_variants_rev")]
        if key is UnionKey.StPunctOnly:
            return [get_slot("st_punctuations")]

        raise KeyError("UnionKey not handled: {}".format(key))

    def _get(self, attr: str) -> DictSlot:
        slot = getattr(self._dict, attr, None)
        if not slot:
            return {}, 0
        dictionary, cap = slot
        return dictionary, int(cap) if cap is not None else 0
